const ErrorHandler = require("../utils/errorHandler");
const catchAsyncErrors = require("../middlewares/cathAsyncErrorsMiddleware");
const sendToken = require("../utils/jwtToken");
const asyncHandler = require("express-async-handler");
const dotenv = require("dotenv");

const db = require("../config/database");

dotenv.config();



exports.addPermissions = asyncHandler(async (req, res, next) => {
  const { roleId } = req.params;
  const { permissionIds } = req.body;

  try {
    if (!roleId || !Array.isArray(permissionIds) || permissionIds.length === 0) {
      return res.status(400).json({ message: "roleId and permissionIds array are required" });
    }

    await db.promise().query('DELETE FROM role_permissions WHERE role_id = ?', [roleId]);

    for (const permissionId of permissionIds) {
      await db.promise().query('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [roleId, permissionId]);
    }

    res.status(200).json({ message: "Permissions updated successfully" });
  } catch (error) {
    next(new ErrorHandler(error.message, 500));
  }
});

exports.getAllPermissions = asyncHandler(async (req, res, next) => {
  try {
    const [permissions] = await db.promise().query('SELECT * FROM permissions');
    res.status(200).json(permissions);
  } catch (error) {
    next(new ErrorHandler(error.message, 500));
  }
});

exports.getUserPermissions = asyncHandler(async (req, res, next) => {
  const { userId } = req.params;

  try {
    const [permissions] = await db.promise().query(`
      SELECT p.name 
      FROM users u
      JOIN user_roles ur ON u.id = ur.user_id
      JOIN role_permissions rp ON ur.role_id = rp.role_id
      JOIN permissions p ON rp.permission_id = p.id
      WHERE u.id = ?
    `, [userId]);

    res.status(200).json(permissions);
  } catch (error) {
    next(new ErrorHandler(error.message, 500));
  }
});





