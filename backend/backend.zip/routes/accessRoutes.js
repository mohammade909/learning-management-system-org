const express = require('express');

const router = express.Router()
const {addPermissions,getAllPermissions, getUserPermissions} = require('../controllers/AccessController')
router.post('/roles/:roleId', addPermissions);
router.get('/users/:userId', getUserPermissions);
router.get('/', getAllPermissions);
module.exports = router